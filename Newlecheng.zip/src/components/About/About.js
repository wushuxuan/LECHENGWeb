import React, { Component }  from 'react';
import $ from 'jquery';
import {Link} from 'react-router-dom';

class About extends Component{
  componentDidMount() {

  };
  render(){
    return (
      <div>
        LECHENG短租是一款租房类APP，前期的问卷调查，到产品原型再到交互逻辑，经过一系列的思考，从特色房源和大学生短租入手，做了这款比较有针对性的租房类管理系统。
      </div>
    );
  }
};

export default About;
